package WebGUI::i18n::BrazilianPortuguese::Asset_Template;
use utf8;

our $I18N = {
};

1;
