package WebGUI::i18n::BrazilianPortuguese::Macro_r_printable;
use utf8;

our $I18N = {
};

1;
