package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_SyncProfilesToLdap;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265209,
    'message' => 'Sincronizar Perfis Para LDAP'
  }
}
;

1;
