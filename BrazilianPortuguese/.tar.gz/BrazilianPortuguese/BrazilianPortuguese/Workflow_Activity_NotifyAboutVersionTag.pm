package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_NotifyAboutVersionTag;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265583,
    'message' => 'Notificar Sobre Etiqueta de Vers&atilde;o'
  }
}
;

1;
