package WebGUI::i18n::BrazilianPortuguese::TransactionLog;
use utf8;

our $I18N = {
};

1;
