package WebGUI::i18n::BrazilianPortuguese::Image_Graph_Pie;
use utf8;

our $I18N = {
};

1;
