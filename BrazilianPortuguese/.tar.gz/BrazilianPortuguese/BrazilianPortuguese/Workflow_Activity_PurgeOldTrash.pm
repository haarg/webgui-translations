package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_PurgeOldTrash;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265569,
    'message' => 'Expirar Itens Antigos da Lixeira'
  }
}
;

1;
