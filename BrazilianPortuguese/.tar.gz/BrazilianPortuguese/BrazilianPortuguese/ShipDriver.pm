package WebGUI::i18n::BrazilianPortuguese::ShipDriver;
use utf8;

our $I18N = {
};

1;
