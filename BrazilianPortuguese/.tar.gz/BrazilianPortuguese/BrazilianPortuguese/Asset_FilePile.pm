package WebGUI::i18n::BrazilianPortuguese::Asset_FilePile;
use utf8;


our $I18N = {
	'upload files description' => {
		message => q||,
		lastUpdated => 0	},

	'108 description' => {
		message => q||,
		lastUpdated => 0	},

	'upload files' => {
		message => q|Selecionar arquivos|,
		lastUpdated => 1168971503
	},

	'872' => {
		message => q|Quem pode visualizar?|,
		lastUpdated => 1168971441
	},

	'108' => {
		message => q|Dono|,
		lastUpdated => 1168971406
	},

	'872 description' => {
		message => q||,
		lastUpdated => 0	},

	'assetName' => {
		message => q||,
		lastUpdated => 0	},

	'871 description' => {
		message => q||,
		lastUpdated => 0	},

	'871' => {
		message => q|Quem pode editar?|,
		lastUpdated => 1168971423
	},

	'940 description' => {
		message => q||,
		lastUpdated => 0	},

	'886' => {
		message => q|Ocultar da navegação?|,
		lastUpdated => 1168971460
	},

	'940' => {
		message => q|Abrir em nova janela ?|,
		lastUpdated => 1168971477
	},

	'add pile' => {
		message => q||,
		lastUpdated => 0	},

	'886 description' => {
		message => q||,
		lastUpdated => 0	},

};

1;
