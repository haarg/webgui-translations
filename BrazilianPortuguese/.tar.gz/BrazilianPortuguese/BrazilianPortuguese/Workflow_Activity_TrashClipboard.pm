package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_TrashClipboard;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265137,
    'message' => 'Esvaziar &Aacute;rea de Transfer&ecirc;ncia'
  },
  'trash after' => {
    'lastUpdated' => 1218265120,
    'message' => 'Apagar Ap&oacute;s'
  }
}
;

1;
