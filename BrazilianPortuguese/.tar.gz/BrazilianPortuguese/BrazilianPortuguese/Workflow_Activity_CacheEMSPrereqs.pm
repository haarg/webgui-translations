package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_CacheEMSPrereqs;
use utf8;

our $I18N = {
};

1;
