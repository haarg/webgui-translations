package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_RunCommandAsUser;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265350,
    'message' => 'Executar Comando Como Usu&aacute;rio'
  },
  'command' => {
    'lastUpdated' => 1218265356,
    'message' => 'Comando'
  }
}
;

1;
