package WebGUI::i18n::BrazilianPortuguese::Asset_Subscription;
use utf8;

our $I18N = {
};

1;
