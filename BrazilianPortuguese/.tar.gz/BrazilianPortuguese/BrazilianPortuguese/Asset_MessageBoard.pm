package WebGUI::i18n::BrazilianPortuguese::Asset_MessageBoard;
use utf8;


our $I18N = {
	'74' => {
		message => q||,
		lastUpdated => 0	},

	'6' => {
		message => q|Editar Quadro de F�runs|,
		lastUpdated => 1096145195
	},

	'75' => {
		message => q|Adicionar um f�rum|,
		lastUpdated => 1080069052
	},

	'73' => {
		message => q|Modelo de Quadro de F�runs|,
		lastUpdated => 1096145237
	},

	'76' => {
		message => q|Voc� tem certeza de que quer apagar esta discuss�o, e todas as mensagens nela contidas ?|,
		lastUpdated => 1096145016
	},

};

1;
