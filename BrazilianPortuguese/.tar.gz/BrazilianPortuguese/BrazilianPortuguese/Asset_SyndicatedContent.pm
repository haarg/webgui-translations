package WebGUI::i18n::BrazilianPortuguese::Asset_SyndicatedContent;
use utf8;


our $I18N = {
	'4' => {
		message => q|Editar Conte�do Sindicado (RSS)|,
		lastUpdated => 1080079188
	},

	'1' => {
		message => q|URL para o arquivo RSS|,
		lastUpdated => 1080079277
	},

	'72' => {
		message => q|Modelo de Conte�do Sindicado (RSS)|,
		lastUpdated => 1080079227
	},

	'3' => {
		message => q|N�mero M�ximo de <i>Headlines</i>|,
		lastUpdated => 1080079176
	},

};

1;
