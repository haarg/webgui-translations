package WebGUI::i18n::BrazilianPortuguese::CommerceShippingByPrice;
use utf8;

our $I18N = {
};

1;
