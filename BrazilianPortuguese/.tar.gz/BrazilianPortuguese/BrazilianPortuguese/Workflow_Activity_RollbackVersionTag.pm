package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_RollbackVersionTag;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265381,
    'message' => 'Reverter Etiqueta de Vers&atilde;o'
  }
}
;

1;
