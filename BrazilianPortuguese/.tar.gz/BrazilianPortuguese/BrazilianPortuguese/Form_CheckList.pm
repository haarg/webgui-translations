package WebGUI::i18n::BrazilianPortuguese::Form_CheckList;
use utf8;

our $I18N = {
	'topicName' => {
		message => q|WebGUI Form CheckList|,
		lastUpdated => 1202593059
	},

	'selectAll label' => {
		message => q|Selecionar Todos|,
		lastUpdated => 1202593047
	},

};

1;
