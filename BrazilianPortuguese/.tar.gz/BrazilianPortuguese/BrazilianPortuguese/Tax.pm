package WebGUI::i18n::BrazilianPortuguese::Tax;
use utf8;

our $I18N = {
};

1;
