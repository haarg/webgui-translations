package WebGUI::i18n::BrazilianPortuguese::PayDriver_ITransact;
use utf8;

our $I18N = {
};

1;
