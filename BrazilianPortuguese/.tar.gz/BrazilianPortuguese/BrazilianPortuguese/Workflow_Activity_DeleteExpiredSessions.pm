package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_DeleteExpiredSessions;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265975,
    'message' => 'Apagar Sess&otilde;es Expiradas'
  }
}
;

1;
