package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_SendQueuedMailMessages;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265329,
    'message' => 'Enviar Mensagens'
  }
}
;

1;
