package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_RequestApprovalForVersionTag;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265401,
    'message' => 'Solicitar Aprova&ccedil;&atilde;o para Etiqueta de Vers&atilde;o'
  }
}
;

1;
