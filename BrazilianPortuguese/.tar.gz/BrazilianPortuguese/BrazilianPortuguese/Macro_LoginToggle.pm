package WebGUI::i18n::BrazilianPortuguese::Macro_LoginToggle;
use utf8;

our $I18N = {
};

1;
