package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_NotifyAdminsWithOpenVersionTags;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265544,
    'message' => 'Notificar Adminsitradores Sobre Etiquetas de Vers&otilde;es Antigas'
  }
}
;

1;
