package WebGUI::i18n::BrazilianPortuguese::Asset_DataTable;
use utf8;
our $I18N = {};

1;
