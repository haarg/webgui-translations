package WebGUI::i18n::BrazilianPortuguese::CommercePaymentCash;
use utf8;

our $I18N = {
};

1;
