package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_PurgeOldInboxMessages;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265554,
    'message' => 'Expirar Mensagens Antigas do Inbox'
  },
  'editForm purgeAfter label' => {
    'lastUpdated' => 1218265492,
    'message' => 'Apagar Ap&oacute;s'
  }
}
;

1;
