package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_GetSyndicatedContent;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265804,
    'message' => 'Receber Conte&uacute;do Sindicado'
  }
}
;

1;
