package WebGUI::i18n::BrazilianPortuguese::Form_MimeType;
use utf8;

our $I18N = {
	'mimeType' => {
		message => q|Tipo MIME|,
		lastUpdated => 1202593139
	},

};

1;
