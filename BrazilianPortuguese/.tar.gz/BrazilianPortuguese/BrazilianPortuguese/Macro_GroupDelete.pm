package WebGUI::i18n::BrazilianPortuguese::Macro_GroupDelete;
use utf8;

our $I18N = {
};

1;
