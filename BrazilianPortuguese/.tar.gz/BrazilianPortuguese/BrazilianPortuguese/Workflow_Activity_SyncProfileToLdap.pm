package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_SyncProfileToLdap;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265199,
    'message' => 'Sincronizar Perfil Para LDAP'
  }
}
;

1;
