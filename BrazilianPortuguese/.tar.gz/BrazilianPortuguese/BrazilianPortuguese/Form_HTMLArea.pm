package WebGUI::i18n::BrazilianPortuguese::Form_HTMLArea;
use utf8;

our $I18N = {
	'rich editor load error' => {
		message => q|N&atilde;o foi poss&iacute;vel ativar a inst&acirc;ncia do editor WYSIWYG.|,
		lastUpdated => 1202593098
	},

};

1;
