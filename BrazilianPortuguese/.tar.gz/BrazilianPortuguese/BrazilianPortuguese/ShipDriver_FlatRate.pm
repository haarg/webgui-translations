package WebGUI::i18n::BrazilianPortuguese::ShipDriver_FlatRate;
use utf8;

our $I18N = {
};

1;
