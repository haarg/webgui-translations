package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_NotifyAboutUser;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265596,
    'message' => 'Notificar Sobre Usu&aacute;rio'
  },
  'message' => {
    'lastUpdated' => 1218265601,
    'message' => 'Mensagem'
  },
  'subject' => {
    'lastUpdated' => 1218265611,
    'message' => 'Assunto'
  },
  'to' => {
    'lastUpdated' => 1218265617,
    'message' => 'Para'
  }
}
;

1;
