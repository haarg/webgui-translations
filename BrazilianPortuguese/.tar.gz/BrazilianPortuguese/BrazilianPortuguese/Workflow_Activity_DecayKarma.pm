package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_DecayKarma;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265986,
    'message' => 'Decair Karma'
  },
  'decay factor' => {
    'lastUpdated' => 1218266003,
    'message' => 'Fator de Decaimento'
  },
  'minimum karma' => {
    'lastUpdated' => 1218266011,
    'message' => 'Karma M&iacute;nimo'
  }
}
;

1;
