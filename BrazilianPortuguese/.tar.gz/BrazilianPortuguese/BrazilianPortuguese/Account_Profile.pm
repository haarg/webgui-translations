package WebGUI::i18n::BrazilianPortuguese::Account_Profile;
use utf8;
our $I18N = {};

1;
