package WebGUI::i18n::BrazilianPortuguese::Asset_Navigation;
use utf8;


our $I18N = {
	'32' => {
		message => q|Exibir p�ginas de acesso restrito|,
		lastUpdated => 1080070593
	},

	'30' => {
		message => q|Exibir p�ginas do sistema|,
		lastUpdated => 1080070471
	},

	'31' => {
		message => q|Exibir p�ginas ocultas|,
		lastUpdated => 1080070480
	},

	'22' => {
		message => q|Editar Navega��o|,
		lastUpdated => 1080070295
	},

};

1;
