package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_ExpireSubscriptionCodes;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265912,
    'message' => 'Expirar C&oacute;digos de Assinatura'
  }
}
;

1;
