package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_TrashExpiredEvents;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265090,
    'message' => 'Apagar Eventos Expirados'
  },
  'trash after' => {
    'lastUpdated' => 1218265100,
    'message' => 'Apagar Ap&oacute;s'
  }
}
;

1;
