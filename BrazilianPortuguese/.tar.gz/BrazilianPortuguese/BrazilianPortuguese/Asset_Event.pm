package WebGUI::i18n::BrazilianPortuguese::Asset_Event;
use utf8;
our $I18N = {
  'add/edit title' => {
    'lastUpdated' => undef,
    'message' => ''
  },
  'assetName' => {
    'lastUpdated' => 1168971319,
    'message' => 'Evento'
  },
  'end' => {
    'lastUpdated' => 1218264042,
    'message' => 'Fim'
  },
  'errors' => {
    'lastUpdated' => 1218264051,
    'message' => 'Erros!'
  },
  'locale' => {
    'lastUpdated' => undef,
    'message' => ''
  }
}
;

1;
