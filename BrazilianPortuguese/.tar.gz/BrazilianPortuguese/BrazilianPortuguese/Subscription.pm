package WebGUI::i18n::BrazilianPortuguese::Subscription;
use utf8;

our $I18N = {
};

1;
