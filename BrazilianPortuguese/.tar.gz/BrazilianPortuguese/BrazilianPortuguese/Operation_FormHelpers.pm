package WebGUI::i18n::BrazilianPortuguese::Operation_FormHelpers;
use utf8;

our $I18N = {
};

1;
