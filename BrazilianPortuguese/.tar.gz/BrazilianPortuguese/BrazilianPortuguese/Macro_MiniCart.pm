package WebGUI::i18n::BrazilianPortuguese::Macro_MiniCart;
use utf8;

our $I18N = {};

1;
