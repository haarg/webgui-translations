package WebGUI::i18n::BrazilianPortuguese::Account;
use utf8;
our $I18N = {};

1;
