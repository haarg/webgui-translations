package WebGUI::i18n::BrazilianPortuguese::AssetAspect_RssFeed;
use utf8;
our $I18N = {};

1;
