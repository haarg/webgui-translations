package WebGUI::i18n::BrazilianPortuguese::Asset_RSSCapable;
use utf8;

our $I18N = {
};

1;
