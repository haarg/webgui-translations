package WebGUI::i18n::BrazilianPortuguese::Activity_RequestApprovalForVersionTag_ByCommitterGroup;
use utf8;

our $I18N = {
};

1;
