package WebGUI::i18n::BrazilianPortuguese::Macro_FileUrl;
use utf8;

our $I18N = {
};

1;
