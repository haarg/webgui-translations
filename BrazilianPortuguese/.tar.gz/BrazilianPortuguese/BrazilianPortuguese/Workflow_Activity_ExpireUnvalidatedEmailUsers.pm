package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_ExpireUnvalidatedEmailUsers;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265870,
    'message' => 'Expirar Usu&aacute;rios de Emails N&atilde;o-Verificados'
  },
  'interval label' => {
    'lastUpdated' => 1218265880,
    'message' => 'Expirar Em'
  }
}
;

1;
