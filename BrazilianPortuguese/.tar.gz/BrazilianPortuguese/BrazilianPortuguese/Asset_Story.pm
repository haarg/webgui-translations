package WebGUI::i18n::BrazilianPortuguese::Asset_Story;
use utf8;
our $I18N = {};

1;
