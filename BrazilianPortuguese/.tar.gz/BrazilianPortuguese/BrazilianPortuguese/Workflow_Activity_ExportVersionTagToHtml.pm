package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_ExportVersionTagToHtml;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265899,
    'message' => 'Exportar Etiqueta de Vers&atilde;o para HTML'
  }
}
;

1;
