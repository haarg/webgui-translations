package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_SummarizePassiveProfileLog;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265249,
    'message' => 'Resumir Log de Profiling Passivo'
  }
}
;

1;
