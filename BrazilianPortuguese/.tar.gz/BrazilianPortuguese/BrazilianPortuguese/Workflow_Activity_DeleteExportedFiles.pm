package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_DeleteExportedFiles;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265957,
    'message' => 'Apagar Arquivos Exportados'
  }
}
;

1;
