package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_PurgeOldAssetRevisions;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265518,
    'message' => 'Expirar Revis&otilde;es de Assets'
  }
}
;

1;
