package WebGUI::i18n::BrazilianPortuguese::Asset_StoryTopic;
use utf8;
our $I18N = {};

1;
