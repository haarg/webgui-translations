package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_CleanFileCache;
use utf8;

our $I18N = {
};

1;
