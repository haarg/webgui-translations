package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_NotifyAboutLowStock;
use utf8;
our $I18N = {};

1;
