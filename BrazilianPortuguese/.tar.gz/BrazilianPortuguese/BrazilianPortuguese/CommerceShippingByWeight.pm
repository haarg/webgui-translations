package WebGUI::i18n::BrazilianPortuguese::CommerceShippingByWeight;
use utf8;

our $I18N = {
};

1;
