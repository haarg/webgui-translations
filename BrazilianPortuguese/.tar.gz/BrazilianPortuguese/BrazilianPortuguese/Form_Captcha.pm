package WebGUI::i18n::BrazilianPortuguese::Form_Captcha;
use utf8;

our $I18N = {
	'topicName' => {
		message => q|Captcha|,
		lastUpdated => 1202591113
	},

	'verify your humanity' => {
		message => q|Verique Sua Humanidade|,
		lastUpdated => 1202591139
	},

};

1;
