package WebGUI::i18n::BrazilianPortuguese::Form_MatrixCompare;
use utf8;
our $I18N = {};

1;
