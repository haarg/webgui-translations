package WebGUI::i18n::BrazilianPortuguese::Workflow_Activity_TrashVersionTag;
use utf8;
our $I18N = {
  'activityName' => {
    'lastUpdated' => 1218265076,
    'message' => 'Apagar Etiqueta de Vers&atilde;o'
  }
}
;

1;
