package WebGUI::i18n::BrazilianPortuguese::Account_Contributions;
use utf8;
our $I18N = {};

1;
