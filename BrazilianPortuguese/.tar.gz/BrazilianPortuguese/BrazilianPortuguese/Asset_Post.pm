package WebGUI::i18n::BrazilianPortuguese::Asset_Post;
use utf8;

our $I18N = {
};

1;
