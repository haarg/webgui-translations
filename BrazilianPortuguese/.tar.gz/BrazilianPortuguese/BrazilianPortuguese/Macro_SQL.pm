package WebGUI::i18n::BrazilianPortuguese::Macro_SQL;
use utf8;


our $I18N = {
	'illegal query' => {
		message => q|Não é possível realizar este tipo de pesquisa|,
		lastUpdated => 1168971624
	},

	'macroName' => {
		message => q|SQL|,
		lastUpdated => 1168971631
	},

	'sql error' => {
		message => q||,
		lastUpdated => 0	},

};

1;
