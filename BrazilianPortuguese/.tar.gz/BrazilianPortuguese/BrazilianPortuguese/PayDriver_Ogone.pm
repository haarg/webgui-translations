package WebGUI::i18n::BrazilianPortuguese::PayDriver_Ogone;
use utf8;
our $I18N = {};

1;
