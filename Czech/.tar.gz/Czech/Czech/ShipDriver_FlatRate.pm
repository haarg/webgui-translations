package WebGUI::i18n::Czech::ShipDriver_FlatRate;
use utf8;
our $I18N = {};

1;
