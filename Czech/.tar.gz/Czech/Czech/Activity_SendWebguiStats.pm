package WebGUI::i18n::Czech::Activity_SendWebguiStats;
use utf8;
our $I18N = {};

1;
