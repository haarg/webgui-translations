package WebGUI::i18n::Czech::Macro_GroupDelete;
use utf8;
our $I18N = {};

1;
