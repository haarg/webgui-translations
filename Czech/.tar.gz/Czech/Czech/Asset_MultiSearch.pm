package WebGUI::i18n::Czech::Asset_MultiSearch;
use utf8;
our $I18N = {};

1;
