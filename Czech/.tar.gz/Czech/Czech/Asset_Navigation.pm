package WebGUI::i18n::Czech::Asset_Navigation;
use utf8;
our $I18N = {};

1;
