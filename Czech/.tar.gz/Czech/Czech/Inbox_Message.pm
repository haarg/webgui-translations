package WebGUI::i18n::Czech::Inbox_Message;
use utf8;
our $I18N = {};

1;
