package WebGUI::i18n::Czech::Asset_StoryTopic;
use utf8;
our $I18N = {};

1;
