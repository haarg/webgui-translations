package WebGUI::i18n::Czech::Asset_ThingyRecord;
use utf8;
our $I18N = {};

1;
