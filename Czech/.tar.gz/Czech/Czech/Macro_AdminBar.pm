package WebGUI::i18n::Czech::Macro_AdminBar;
use utf8;
our $I18N = {};

1;
