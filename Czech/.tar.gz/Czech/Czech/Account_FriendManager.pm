package WebGUI::i18n::Czech::Account_FriendManager;
use utf8;
our $I18N = {};

1;
