package WebGUI::i18n::Czech::Account;
use utf8;
our $I18N = {
  'account url' => {
    'lastUpdated' => '1233808271',
    'message' => 'Adresa k aktivaci tohoto pluginu.'
  },
  'user_full_name' => {
    'lastUpdated' => '1233808105',
    'message' => "U\x{17e}ivatelovo jm\x{e9}no a p\x{159}\x{ed}jmen\x{ed}"
  },
  'user_member_since' => {
    'lastUpdated' => '1233808238',
    'message' => "Datum kdy si tento u\x{17e}ivatel zalo\x{17e}il t\x{11b}chto str\x{e1}nk\x{e1}ch u\x{17e}ivatelsk\x{fd} \x{fa}\x{10d}et, ve form\x{e1}tu epoch. Ke zm\x{11b}n\x{11b} pou\x{17e}ijte Date makro."
  }
}
;

1;
