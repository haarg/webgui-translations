package WebGUI::i18n::Czech::PayDriver_PayPalStd;
use utf8;
our $I18N = {};

1;
