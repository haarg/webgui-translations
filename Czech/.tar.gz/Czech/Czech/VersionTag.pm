package WebGUI::i18n::Czech::VersionTag;
use utf8;
our $I18N = {};

1;
