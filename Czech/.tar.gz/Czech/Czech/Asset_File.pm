package WebGUI::i18n::Czech::Asset_File;
use utf8;
our $I18N = {
  'title' => {
    'lastUpdated' => '1233808606',
    'message' => "Jm\x{e9}no zvolen\x{e9} p\x{159}i nahr\x{e1}n\x{ed}, nebo p\x{16f}vodn\x{ed} n\x{e1}zev souboru."
  }
}
;

1;
