package WebGUI::i18n::Czech::AdminConsole;
use utf8;
our $I18N = {
  'admin console' => {
    'lastUpdated' => '1233808435',
    'message' => 'Konzole administrátora'
  },
  'toggle off' => {
    'lastUpdated' => '1233808393',
    'message' => 'Schovat konzoli administrátora.'
  },
  'toggle on' => {
    'lastUpdated' => '1233808414',
    'message' => 'Ukázat konzoli administrátora.'
  }
}
;

1;
