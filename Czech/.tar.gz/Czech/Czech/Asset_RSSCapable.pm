package WebGUI::i18n::Czech::Asset_RSSCapable;
use utf8;
our $I18N = {};

1;
