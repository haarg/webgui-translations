package WebGUI::i18n::Czech::Asset_TimeTracking;
use utf8;
our $I18N = {};

1;
