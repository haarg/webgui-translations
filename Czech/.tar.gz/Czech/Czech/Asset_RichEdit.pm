package WebGUI::i18n::Czech::Asset_RichEdit;
use utf8;
our $I18N = {};

1;
