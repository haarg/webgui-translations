package WebGUI::i18n::Czech::ShipDriver;
use utf8;
our $I18N = {};

1;
