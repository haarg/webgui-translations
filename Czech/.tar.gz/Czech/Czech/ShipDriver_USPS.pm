package WebGUI::i18n::Czech::ShipDriver_USPS;
use utf8;
our $I18N = {};

1;
