package WebGUI::i18n::Czech::AuthLDAP;
use utf8;
our $I18N = {};

1;
