package WebGUI::i18n::Czech::Asset_Folder;
use utf8;
our $I18N = {};

1;
