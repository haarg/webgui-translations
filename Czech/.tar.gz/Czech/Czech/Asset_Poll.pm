package WebGUI::i18n::Czech::Asset_Poll;
use utf8;
our $I18N = {};

1;
