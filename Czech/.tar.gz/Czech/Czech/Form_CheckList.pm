package WebGUI::i18n::Czech::Form_CheckList;
use utf8;
our $I18N = {};

1;
