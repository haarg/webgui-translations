package WebGUI::i18n::Czech::Workflow_Cron;
use utf8;
our $I18N = {};

1;
