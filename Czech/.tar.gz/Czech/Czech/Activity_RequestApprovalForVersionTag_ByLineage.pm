package WebGUI::i18n::Czech::Activity_RequestApprovalForVersionTag_ByLineage;
use utf8;
our $I18N = {};

1;
