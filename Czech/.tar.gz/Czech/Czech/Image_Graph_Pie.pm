package WebGUI::i18n::Czech::Image_Graph_Pie;
use utf8;
our $I18N = {};

1;
