package WebGUI::i18n::Czech::TaxDriver_EU;
use utf8;
our $I18N = {};

1;
