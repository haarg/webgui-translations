package WebGUI::i18n::Czech::Asset_FlatDiscount;
use utf8;
our $I18N = {};

1;
