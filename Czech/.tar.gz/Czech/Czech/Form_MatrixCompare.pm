package WebGUI::i18n::Czech::Form_MatrixCompare;
use utf8;
our $I18N = {};

1;
