package WebGUI::i18n::Czech::PayDriver_PayPal;
use utf8;
our $I18N = {};

1;
