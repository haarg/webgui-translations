package WebGUI::i18n::Czech::PassiveAnalytics;
use utf8;
our $I18N = {};

1;
