package WebGUI::i18n::Czech::Asset_Shortcut;
use utf8;
our $I18N = {};

1;
