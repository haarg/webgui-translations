package WebGUI::i18n::Czech::Spectre;
use utf8;
our $I18N = {};

1;
