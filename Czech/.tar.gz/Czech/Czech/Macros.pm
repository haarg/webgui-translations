package WebGUI::i18n::Czech::Macros;
use utf8;
our $I18N = {};

1;
