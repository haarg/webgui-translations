package WebGUI::i18n::Czech::Macro_MiniCart;
use utf8;
our $I18N = {};

1;
