package WebGUI::i18n::Czech::Asset_SQLReport;
use utf8;
our $I18N = {};

1;
