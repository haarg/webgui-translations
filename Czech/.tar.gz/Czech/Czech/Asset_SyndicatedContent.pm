package WebGUI::i18n::Czech::Asset_SyndicatedContent;
use utf8;
our $I18N = {};

1;
