package WebGUI::i18n::Czech::Graphics;
use utf8;
our $I18N = {
  'add color' => {
    'lastUpdated' => '1233808505',
    'message' => "P\x{159}idat do t\x{e9}to palety barvu."
  }
}
;

1;
