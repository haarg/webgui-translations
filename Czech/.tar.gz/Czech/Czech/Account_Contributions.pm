package WebGUI::i18n::Czech::Account_Contributions;
use utf8;
our $I18N = {
  'date label' => {
    'lastUpdated' => '1233808305',
    'message' => 'Datum'
  }
}
;

1;
