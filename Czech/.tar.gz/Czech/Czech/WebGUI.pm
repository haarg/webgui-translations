package WebGUI::i18n::Czech::WebGUI;
use utf8;
our $I18N = {};

1;
