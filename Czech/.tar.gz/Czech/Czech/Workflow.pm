package WebGUI::i18n::Czech::Workflow;
use utf8;
our $I18N = {};

1;
