package WebGUI::i18n::Czech::Asset_StockData;
use utf8;
our $I18N = {};

1;
