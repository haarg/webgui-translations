package WebGUI::i18n::Czech::Form_HTMLArea;
use utf8;
our $I18N = {};

1;
