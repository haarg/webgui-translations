package WebGUI::i18n::Czech::Icon;
use utf8;
our $I18N = {};

1;
