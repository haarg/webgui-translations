package WebGUI::i18n::Czech::Image_Graph_XYGraph_Bar;
use utf8;
our $I18N = {};

1;
