package WebGUI::i18n::Czech::Account_Shop;
use utf8;
our $I18N = {};

1;
