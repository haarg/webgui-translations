package WebGUI::i18n::Czech::Macro_EditableToggle;
use utf8;
our $I18N = {};

1;
